#define F_CPU 8000000UL // 8 MHz clock speed
#include <avr/io.h>
#include <util/delay.h>
#include "avr.h"
#include "lcd.h"
#include "stdio.h"
#include <avr/wdt.h>
#include <stdlib.h>

#define NUM_LEDS 50 
#define MAX_COLOR_SEQUENCE 100 

typedef enum {
	As5 = 932,
	C4 = 261,
	Cs4_Db4 = 277,
	D4 = 293,
	Ds4_Eb4 = 311,
	E4 = 329,
	F4 = 349,
	Fs4_Gb4 = 370,
	G4 = 392,
	Gs4_Ab4 = 415,
	A4 = 440,
	As4_Bb4 = 466,
	B4 = 493,
	C5 = 523,
	Cs5_Db5 = 554,
	D5 = 587,
	Ds5_Eb5 = 622,
	E5 = 659,
	F5 = 698,
	Fs5_Gb5 = 739,
	G5 = 783,
	Gs5_Ab5 = 830,
	A5 = 880,
	B5 = 988,
	C6 = 1046,
	D6 = 1175,
	E6 = 1319,
	F6 = 1397,
	G6 = 1568,
	A6 = 1760,
	B3 = 247,
	Bb3 = 233,
	G3 = 196,
	E3 = 165,
	A3 = 220,
	Cs6_Db6 = 1109
} Note;

typedef struct {
	Note frequency;
	float duration;
} PlayingNote;

typedef struct {
	uint8_t red;
	uint8_t green;
	uint8_t blue;
	PlayingNote note;
} ColorNote;

char bufMsg[17];
void send_ws2812b_bit(uint8_t bit);
void send_ws2812b_byte(uint8_t byte);
void send_ws2812b_color(uint8_t red, uint8_t green, uint8_t blue);
void send_ws2812b_reset(void);

ColorNote color_sequence[MAX_COLOR_SEQUENCE];
int color_sequence_index = 0;

char keymap[4][4] = {
	{'1', '2', '3', 'A'},
	{'4', '5', '6', 'B'},
	{'7', '8', '9', 'C'},
	{'*', '0', '#', 'D'}
};

unsigned char stop_music = 0;
unsigned char stop_colors = 0;
unsigned char music_on = 0; 
unsigned char last_touch_state = 1;
unsigned char current_color = 0;

PlayingNote do_note = {C4, 0.25};
PlayingNote re_note = {D4, 0.25};
PlayingNote mi_note = {E4, 0.25};
PlayingNote fa_note = {F4, 0.25};
PlayingNote sol_note = {G4, 0.25};
PlayingNote la_note = {A4, 0.25};
PlayingNote si_note = {B4, 0.25};
PlayingNote do_high_note = {C5, 0.25};
PlayingNote touch_note = {C6, 0.25}; 

unsigned int isPressed(int r, int c) {
	// reset all pins
	DDRC = 0x00;
	PORTC = 0x00;

	// row output
	DDRC |= (1 << r);
	PORTC &= ~(1 << r);
	// adjust column index
	c += 4;
	DDRC &= ~(1 << c);
	PORTC |= (1 << c);

	avr_wait(10);

	if ((PINC & (1 << c)) == 0) {
		avr_wait(10);
		return 1;
	}
	return 0;
}

unsigned char get_key() {
	int r, c;
	for (r = 0; r < 4; ++r) {
		for (c = 0; c < 4; ++c) {
			if (isPressed(r, c)) {
				avr_wait(50);
				if (isPressed(r, c)) {
					return keymap[r][c];
				}
			}
		}
	}
	return 0;
}

void display_message(const char *msg) {
	lcd_clr();
	lcd_pos(0, 0);
	lcd_puts2(msg);
}

void avr_wait2(unsigned short msec) {
	TCCR0 = 2;
	while (msec--) {
		TCNT0 = (unsigned char)(256 - (XTAL_FRQ / 8) * 0.00001); // 10 msc
		SET_BIT(TIFR, TOV0);
		WDR();
		while (!GET_BIT(TIFR, TOV0));
	}
	TCCR0 = 0;
}

void set_color(uint8_t red, uint8_t green, uint8_t blue) {
	send_ws2812b_reset();
	for (int i = 0; i < NUM_LEDS; ++i) {
		send_ws2812b_color(red, green, blue);
	}
	send_ws2812b_reset();
}

void record_color_sequence(uint8_t red, uint8_t green, uint8_t blue, PlayingNote note) {
	if (color_sequence_index < MAX_COLOR_SEQUENCE) {
		color_sequence[color_sequence_index].red = red;
		color_sequence[color_sequence_index].green = green;
		color_sequence[color_sequence_index].blue = blue;
		color_sequence[color_sequence_index].note = note;
		color_sequence_index++;
	}
}

void play_note_with_controls(const PlayingNote* note) {
	SET_BIT(DDRA, 3);  // PA3 output

	unsigned int period = (unsigned int)(100000 / note->frequency); // T = 1/f
	unsigned int high_time = period / 2; // waveform at high
	unsigned int low_time = period - high_time; // waveform at low, other half period
	unsigned int total_cycles = (unsigned int)(note->frequency * note->duration); // frequency * duration

	for (unsigned int cycle = 0; cycle < total_cycles; ++cycle) {
		if (stop_music) break;
		SET_BIT(PORTA, 3);
		avr_wait2(high_time);
		CLR_BIT(PORTA, 3);
		avr_wait2(low_time);
	}
}

void play_song_with_controls(PlayingNote song[], int length) {
	for (int i = 0; i < length; i++) {
		if (stop_music) break;
		play_note_with_controls(&song[i]);
	}
}

void play_color_sequence() {
	for (int i = 0; i < color_sequence_index; ++i) {
		set_color(color_sequence[i].red, color_sequence[i].green, color_sequence[i].blue);
		play_note_with_controls(&color_sequence[i].note);
		_delay_ms(250); 
	}
}

void reset_color_sequence() {
	color_sequence_index = 0;
	set_color(0, 0, 0); // Turn off all LEDs
	display_message("Colors Reset");
}

void play_light_show() {
	
	for (int i = 0; i < 50; ++i) {
		
		if (get_key() == '#') {
			break;
		}
		uint8_t red = rand() % 256;
		uint8_t green = rand() % 256;
		uint8_t blue = rand() % 256;
		set_color(red, green, blue);
		_delay_ms(100);
		set_color(0, 0, 0);
		_delay_ms(50); 
	}
	set_color(0, 0, 0); 
}


int main(void) {
	lcd_init();
	display_message("Press 1-9 to record colors");

	
	SET_BIT(DDRA, PA0);


	CLR_BIT(DDRA, PA1);
	SET_BIT(PORTA, PA1); 

	while (1) {
		unsigned char key = get_key();
		

		unsigned char touch_state = PINA & (1 << PA1);
		if (touch_state == 0 && last_touch_state != 0) {
			current_color++;
			if (current_color > 3) {
				current_color = 0;
			}
			switch (current_color) {
				case 0:
				set_color(255, 0, 0); // Red
				display_message("Red Light");
				break;
				case 1:
				set_color(0, 255, 0); // Green
				display_message("Green Light");
				break;
				case 2:
				set_color(0, 0, 255); // Blue
				display_message("Blue Light");
				break;
				case 3:
				set_color(255, 255, 0); // Yellow
				display_message("Yellow Light");
				break;
			}
			play_note_with_controls(&touch_note);
		}
		last_touch_state = touch_state;

		switch (key) {
			case '1':
			record_color_sequence(255, 0, 0, do_note); // Red with Do note
			set_color(255, 0, 0); // Red color
			play_note_with_controls(&do_note);
			display_message("Red Recorded");
			break;
			case '2':
			record_color_sequence(0, 255, 0, re_note); // Green with Re note
			set_color(0, 255, 0); // Green color
			play_note_with_controls(&re_note);
			display_message("Green Recorded");
			break;
			case '3':
			record_color_sequence(0, 0, 255, mi_note); // Blue with Mi note
			set_color(0, 0, 255); // Blue color
			play_note_with_controls(&mi_note);
			display_message("Blue Recorded");
			break;
			case '4':
			record_color_sequence(255, 255, 0, fa_note); // Yellow with Fa note
			set_color(255, 255, 0); // Yellow color
			play_note_with_controls(&fa_note);
			display_message("Yellow Recorded");
			break;
			case '5':
			record_color_sequence(255, 165, 0, sol_note); // Orange with Sol note
			set_color(255, 165, 0); // Orange color
			play_note_with_controls(&sol_note);
			display_message("Orange Recorded");
			break;
			case '6':
			record_color_sequence(75, 0, 130, la_note); // Indigo with La note
			set_color(75, 0, 130); // Indigo color
			play_note_with_controls(&la_note);
			display_message("Indigo Recorded");
			break;
			case '7':
			record_color_sequence(238, 130, 238, si_note); // Violet with Si note
			set_color(238, 130, 238); // Violet color
			play_note_with_controls(&si_note);
			display_message("Violet Recorded");
			break;
			case '8':
			record_color_sequence(255, 20, 147, do_high_note); // Deep Pink with high Do note
			set_color(255, 20, 147); // Deep Pink color
			play_note_with_controls(&do_high_note);
			display_message("Deep Pink Recorded");
			break;
			case '9':
			record_color_sequence(0, 255, 255, touch_note); // Cyan with touch_note
			set_color(0, 255, 255); // Cyan color
			play_note_with_controls(&touch_note);
			display_message("Cyan Recorded");
			break;
			case '0':
			display_message("Playing Colors");
			play_color_sequence();
			display_message("Playback Finished");
			break;
			case 'D':
			display_message("Playing Light Show");
			play_light_show();
			display_message("Light Show Finished");
			break;
			case '#':
			reset_color_sequence();
			break;
		}
		avr_wait(100); 
	}

	return 0;
}

void send_ws2812b_bit(uint8_t bit) {
	if (bit) {
		asm volatile (
		"sbi %[port], %[bit] \n\t"       // Set PA0 high
		"nop \n\t" "nop \n\t" "nop \n\t" "nop \n\t" // 4 NOPs, ~500 ns
		"cbi %[port], %[bit] \n\t"       // Set PA0 low
		"nop \n\t" "nop \n\t" // 2 NOPs, ~250 ns
		:
		: [port] "I" (_SFR_IO_ADDR(PORTA)), [bit] "I" (PA0)
		);
		} else {
		asm volatile (
		"sbi %[port], %[bit] \n\t"       // Set PA0 high
		"nop \n\t" // 1 NOP, ~125 ns
		"cbi %[port], %[bit] \n\t"       // Set PA0 low
		"nop \n\t" "nop \n\t" "nop \n\t" "nop \n\t" "nop \n\t" "nop \n\t" // 6 NOPs, ~750 ns
		:
		: [port] "I" (_SFR_IO_ADDR(PORTA)), [bit] "I" (PA0)
		);
	}
}

void send_ws2812b_byte(uint8_t byte) {
	for (uint8_t i = 0; i < 8; i++) {
		send_ws2812b_bit(byte & (1 << (7 - i)));
	}
}

void send_ws2812b_color(uint8_t red, uint8_t green, uint8_t blue) {
	send_ws2812b_byte(green);
	send_ws2812b_byte(red);
	send_ws2812b_byte(blue);
}

void send_ws2812b_reset(void) {
	avr_wait(80); 
}
